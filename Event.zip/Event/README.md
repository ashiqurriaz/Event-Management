# Event-Management
Event Management is a online platform that maintain event order in online. 
